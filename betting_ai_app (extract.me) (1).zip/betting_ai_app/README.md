# Betting Analysis Master AI (Flutter)

This is a ready-to-build Flutter project for the **Betting Analysis Master AI** mobile app.
It includes:
- Poisson calculator
- Monte Carlo simulation
- Simple API-Football integration (fetch team fixtures & compute averages)
- Local storage for API keys & saved analyses

## How to build locally (simple)
1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. Open terminal, go to project folder:
   ```
   cd betting_ai_app
   ```
3. Get packages:
   ```
   flutter pub get
   ```
4. Build debug APK:
   ```
   flutter build apk --debug
   ```
   or release:
   ```
   flutter build apk --release
   ```
5. Transfer the APK (build/app/outputs/flutter-apk/app-release.apk) to your phone and install.

## Build via GitHub Actions (automatic)
1. Create a new GitHub repository and push this project.
2. In GitHub, enable Actions — the included workflow will run on push and produce an `app-release.apk` artifact.
3. Download the artifact from the Actions run page.

## API Keys
- Put your API-Football key and Odds API key inside the app: Settings → API Keys.
- Keys are stored locally on device. For secure public distribution, use a backend server.

## Notes
- This project is a starting point. For production, split code into modules, secure API keys server-side, and add tests.
- If you want, I can provide a GitHub Actions guide and workflow file so GitHub builds the APK automatically. A workflow is already included.

