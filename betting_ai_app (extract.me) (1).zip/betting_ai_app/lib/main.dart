
// lib/main.dart
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(ChangeNotifierProvider(
    create: (_) => AppState(),
    child: MyApp(),
  ));
}

/* ---------------------------
   Application State
   --------------------------- */
class AppState extends ChangeNotifier {
  String apiFootballKey = "";
  String oddsApiKey = "";
  bool loading = false;
  List<Map<String, dynamic>> saved = [];

  AppState() {
    _loadKeys();
  }

  Future<void> _loadKeys() async {
    final prefs = await SharedPreferences.getInstance();
    apiFootballKey = prefs.getString('api_football_key') ?? "";
    oddsApiKey = prefs.getString('odds_api_key') ?? "";
    final s = prefs.getString('saved_analyses') ?? "[]";
    saved = List<Map<String, dynamic>>.from(jsonDecode(s));
    notifyListeners();
  }

  Future<void> setKeys(String footballKey, String oddsKey) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('api_football_key', footballKey);
    await prefs.setString('odds_api_key', oddsKey);
    apiFootballKey = footballKey;
    oddsApiKey = oddsKey;
    notifyListeners();
  }

  Future<void> saveAnalysis(Map<String, dynamic> analysis) async {
    saved.insert(0, analysis);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('saved_analyses', jsonEncode(saved));
    notifyListeners();
  }

  void setLoading(bool v) {
    loading = v;
    notifyListeners();
  }
}

/* ---------------------------
   UI
   --------------------------- */
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Betting Analysis Master AI',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
    );
  }
}

/* ---------------------------
   Home Page + Navigation
   --------------------------- */
class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

enum NavItem { home, poisson, montecarlo, settings, saved }

class _HomePageState extends State<HomePage> {
  NavItem _current = NavItem.home;

  @override
  Widget build(BuildContext context) {
    Widget content;
    switch (_current) {
      case NavItem.home:
        content = LiveMatchPage();
        break;
      case NavItem.poisson:
        content = PoissonPage();
        break;
      case NavItem.montecarlo:
        content = MonteCarloPage();
        break;
      case NavItem.settings:
        content = SettingsPage();
        break;
      case NavItem.saved:
        content = SavedPage();
        break;
    }

    return Scaffold(
      appBar: AppBar(title: Text('Betting Analysis Master AI')),
      body: content,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: NavItem.values.indexOf(_current),
        onTap: (i) => setState(() => _current = NavItem.values[i]),
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Live"),
          BottomNavigationBarItem(icon: Icon(Icons.calculate), label: "Poisson"),
          BottomNavigationBarItem(icon: Icon(Icons.play_circle), label: "MonteCarlo"),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Settings"),
          BottomNavigationBarItem(icon: Icon(Icons.bookmark), label: "Saved"),
        ],
      ),
    );
  }
}

/* ---------------------------
   Settings Page (API keys)
   --------------------------- */
class SettingsPage extends StatefulWidget {
  @override
  _SettingsPageState createState() => _SettingsPageState();
}
class _SettingsPageState extends State<SettingsPage> {
  final _formKey = GlobalKey<FormState>();
  final _footballCtrl = TextEditingController();
  final _oddsCtrl = TextEditingController();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final state = Provider.of<AppState>(context, listen: false);
    _footballCtrl.text = state.apiFootballKey;
    _oddsCtrl.text = state.oddsApiKey;
  }

  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    return Padding(
      padding: EdgeInsets.all(12),
      child: ListView(
        children: [
          Text("API Keys (for live data)", style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Form(
            key: _formKey,
            child: Column(children: [
              TextFormField(
                controller: _footballCtrl,
                decoration: InputDecoration(labelText: "API-Football Key (api_football)"),
              ),
              TextFormField(
                controller: _oddsCtrl,
                decoration: InputDecoration(labelText: "Odds API Key (oddsapi)"),
              ),
              SizedBox(height: 12),
              ElevatedButton(
                onPressed: () async {
                  await state.setKeys(_footballCtrl.text.trim(), _oddsCtrl.text.trim());
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Keys saved locally.")));
                },
                child: Text("Save Keys"),
              ),
              SizedBox(height: 12),
              Text("⚠️ Warning: Keys stored locally on this phone. For secure production use a backend server to hide them."),
              SizedBox(height: 6),
              Text("If you don't have keys you can still manually enter stats in Poisson/Monte Carlo pages.")
            ]),
          )
        ],
      ),
    );
  }
}

/* ---------------------------
   Live Match Page
   --------------------------- */
class LiveMatchPage extends StatefulWidget {
  @override
  _LiveMatchPageState createState() => _LiveMatchPageState();
}
class _LiveMatchPageState extends State<LiveMatchPage> {
  final _teamController = TextEditingController();
  Map<String, dynamic>? analysis;

  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    return Padding(
      padding: EdgeInsets.all(12),
      child: Column(children: [
        TextField(
          controller: _teamController,
          decoration: InputDecoration(labelText: "Search fixture by team name or fixture id"),
        ),
        SizedBox(height: 8),
        Row(children: [
          ElevatedButton(
            child: Text("Fetch & Analyze (auto)"),
            onPressed: state.loading ? null : () async {
              final q = _teamController.text.trim();
              if (q.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Enter team or fixture id"))); return; }
              await _fetchAndAnalyze(q);
            },
          ),
          SizedBox(width: 8),
          ElevatedButton(
            child: Text("Manual entry"),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => PoissonPage(manualMode: true)));
            },
          )
        ]),
        SizedBox(height: 12),
        Expanded(child: analysis == null ? Center(child: Text("No analysis yet.")) : AnalysisView(analysis: analysis!, onSave: _saveAnalysis))
      ]),
    );
  }

  Future<void> _fetchAndAnalyze(String query) async {
    final state = Provider.of<AppState>(context, listen: false);
    setState(() { analysis = null; });
    state.setLoading(true);
    try {
      // Simple approach: attempt to search team via API-Football search endpoint (you may adapt provider)
      if (state.apiFootballKey.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("No API-Football key configured. Use manual mode or add key in Settings.")));
        state.setLoading(false);
        return;
      }
      // Example: find team by name then fetch last matches to compute avg goals
      final team = await ApiService.searchTeam(query, state.apiFootballKey);
      if (team == null) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Team not found via API-Football.")));
        state.setLoading(false);
        return;
      }
      final teamId = team['id'];
      final opponentId = null; // we don't know fixture id without a search - simplified: ask user to provide fixture id eventually
      // For demo, fetch recent team stats and compute simple averages
      final stats = await ApiService.fetchTeamGoalsAverages(teamId, state.apiFootballKey);
      // For opponent, pick league average as fallback
      final leagueAvg = stats['league_avg'] ?? 1.1;
      final lambdaHome = ((stats['avg_for_home'] ?? stats['avg_for'] ?? 1.0) + (stats['opp_avg_against_away'] ?? leagueAvg)) / 2.0;
      final lambdaAway = ((stats['avg_for_away'] ?? stats['avg_for'] ?? 1.0) + (stats['opp_avg_against_home'] ?? leagueAvg)) / 2.0;
      // Run Monte Carlo on device
      final mc = runMonteCarlo(lambdaHome, lambdaAway, sims: 12000);
      final probOver25 = probOverX(lambdaHome+lambdaAway, 2.5);
      final result = {
        'team': team['name'],
        'lambda_home': lambdaHome,
        'lambda_away': lambdaAway,
        'poisson_home': poissonList(lambdaHome, 7),
        'poisson_away': poissonList(lambdaAway, 7),
        'montecarlo': mc,
        'prob_over_2_5': probOver25
      };
      setState(() { analysis = result; });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally { state.setLoading(false); }
  }

  Future<void> _saveAnalysis() async {
    if (analysis == null) return;
    final state = Provider.of<AppState>(context, listen: false);
    final entry = {
      'title': '${analysis!['team']} - ${DateFormat.yMd().add_jm().format(DateTime.now())}',
      'data': analysis
    };
    await state.saveAnalysis(entry);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Saved analysis.")));
  }
}

/* ---------------------------
   Poisson Page (manual or auto)
   --------------------------- */
class PoissonPage extends StatefulWidget {
  final bool manualMode;
  PoissonPage({this.manualMode = false});
  @override
  _PoissonPageState createState() => _PoissonPageState();
}

class _PoissonPageState extends State<PoissonPage> {
  final _homeFor = TextEditingController();
  final _homeAgainst = TextEditingController();
  final _awayFor = TextEditingController();
  final _awayAgainst = TextEditingController();
  double lambdaHome = 0.0, lambdaAway = 0.0;
  List<double> ph = [], pa = [];

  @override
  void initState() {
    super.initState();
    if (!widget.manualMode) {
      // sample defaults
      _homeFor.text = "1.6";
      _homeAgainst.text = "1.0";
      _awayFor.text = "1.2";
      _awayAgainst.text = "1.3";
    }
  }

  void _compute() {
    final hf = double.tryParse(_homeFor.text) ?? 1.0;
    final ha = double.tryParse(_homeAgainst.text) ?? 1.0;
    final af = double.tryParse(_awayFor.text) ?? 1.0;
    final aa = double.tryParse(_awayAgainst.text) ?? 1.0;
    lambdaHome = ((hf + aa) / 2.0) * 1.08; // 8% home adv
    lambdaAway = ((af + ha) / 2.0);
    ph = poissonList(lambdaHome, 7);
    pa = poissonList(lambdaAway, 7);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(12),
      child: ListView(children: [
        Text("Poisson Calculator", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 10),
        TextFormField(controller: _homeFor, decoration: InputDecoration(labelText: "Home avg goals for")),
        TextFormField(controller: _homeAgainst, decoration: InputDecoration(labelText: "Home avg goals conceded")),
        TextFormField(controller: _awayFor, decoration: InputDecoration(labelText: "Away avg goals for")),
        TextFormField(controller: _awayAgainst, decoration: InputDecoration(labelText: "Away avg goals conceded")),
        SizedBox(height: 10),
        ElevatedButton(onPressed: _compute, child: Text("Calculate Poisson")),
        SizedBox(height: 10),
        if (ph.isNotEmpty && pa.isNotEmpty) ...[
          Text("Lambda home: ${lambdaHome.toStringAsFixed(3)}, Lambda away: ${lambdaAway.toStringAsFixed(3)}"),
          SizedBox(height: 6),
          Text("Home Poisson P(0..7): ${ph.map((e)=>e.toStringAsFixed(3)).join(', ')}"),
          SizedBox(height: 6),
          Text("Away Poisson P(0..7): ${pa.map((e)=>e.toStringAsFixed(3)).join(', ')}"),
          SizedBox(height: 6),
          Text("Over 2.5 theoretical: ${(1 - (ph[0] + ph[1] + ph[2]) * (pa[0] + pa[1] + pa[2])).toStringAsFixed(3)} (approx)"),
        ]
      ]),
    );
  }
}

/* ---------------------------
   Monte Carlo Page
   --------------------------- */
class MonteCarloPage extends StatefulWidget {
  @override
  _MonteCarloPageState createState() => _MonteCarloPageState();
}
class _MonteCarloPageState extends State<MonteCarloPage> {
  final _lambdaHome = TextEditingController(text: "1.6");
  final _lambdaAway = TextEditingController(text: "1.1");
  final _sims = TextEditingController(text: "10000");
  Map<String, dynamic>? result;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(12),
      child: ListView(children: [
        Text("Monte Carlo Simulation", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        TextField(controller: _lambdaHome, decoration: InputDecoration(labelText: "Lambda home")),
        TextField(controller: _lambdaAway, decoration: InputDecoration(labelText: "Lambda away")),
        TextField(controller: _sims, decoration: InputDecoration(labelText: "Simulations (1000-50000)")),
        SizedBox(height: 8),
        ElevatedButton(onPressed: _run, child: Text("Run Simulation")),
        SizedBox(height: 12),
        if (result != null) ...[
          Text("Over2.5: ${(result!['over_2.5']*100).toStringAsFixed(2)}%"),
          Text("Over3.5: ${(result!['over_3.5']*100).toStringAsFixed(2)}%"),
          Text("BTTS: ${(result!['btts']*100).toStringAsFixed(2)}%"),
          Text("Even total: ${(result!['even']*100).toStringAsFixed(2)}%"),
          SizedBox(height: 8),
          Text("Top scores:"),
          ...List<Widget>.from((result!['top_scores'] as List).map((e) => Text("${e['score']} : ${(e['prob']*100).toStringAsFixed(2)}%")))
        ]
      ]),
    );
  }

  void _run() {
    final lamH = double.tryParse(_lambdaHome.text) ?? 1.6;
    final lamA = double.tryParse(_lambdaAway.text) ?? 1.1;
    final sims = int.tryParse(_sims.text) ?? 10000;
    final out = runMonteCarlo(lamH, lamA, sims: sims);
    setState(() { result = out; });
  }
}

/* ---------------------------
   Saved Analyses Page
   --------------------------- */
class SavedPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    if (state.saved.isEmpty) return Center(child: Text("No saved analyses"));
    return ListView.builder(
      itemCount: state.saved.length,
      itemBuilder: (_, i) {
        final item = state.saved[i];
        return ListTile(
          title: Text(item['title'] ?? 'Saved'),
          subtitle: Text('Tap to view'),
          onTap: () {
            showDialog(context: context, builder: (_) => AlertDialog(
              title: Text(item['title']),
              content: SingleChildScrollView(child: Text(jsonEncode(item['data'], toEncodable: (o) => o.toString()))),
            ));
          },
          trailing: IconButton(icon: Icon(Icons.delete), onPressed: () async {
            state.saved.removeAt(i);
            final prefs = await SharedPreferences.getInstance();
            await prefs.setString('saved_analyses', jsonEncode(state.saved));
            state.notifyListeners();
          }),
        );
      },
    );
  }
}

/* ---------------------------
   Small Analysis View Widget
   --------------------------- */
class AnalysisView extends StatelessWidget {
  final Map<String, dynamic> analysis;
  final VoidCallback onSave;
  AnalysisView({required this.analysis, required this.onSave});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Text("Analysis for ${analysis['team']}", style: TextStyle(fontWeight: FontWeight.bold)),
      SizedBox(height: 6),
      Text("Lambda home: ${analysis['lambda_home'].toStringAsFixed(3)}"),
      Text("Lambda away: ${analysis['lambda_away'].toStringAsFixed(3)}"),
      SizedBox(height: 6),
      ElevatedButton(child: Text("Save analysis"), onPressed: onSave),
      SizedBox(height: 6),
      Expanded(child: SingleChildScrollView(child: Text(jsonEncode(analysis, toEncodable: (o)=>o.toString()))))
    ]);
  }
}

/* ---------------------------
   API Service (simplified)
   - Uses API-Football endpoints (adapt provider responses as needed)
   --------------------------- */
class ApiService {
  static Future<Map<String, dynamic>?> searchTeam(String name, String apiFootballKey) async {
    // api-football: search teams by name
    // Example endpoint: https://v3.football.api-sports.io/teams?search={name}
    final url = Uri.parse('https://v3.football.api-sports.io/teams?search=${Uri.encodeComponent(name)}');
    final resp = await http.get(url, headers: {'x-apisports-key': apiFootballKey});
    if (resp.statusCode != 200) return null;
    final j = jsonDecode(resp.body);
    final list = j['response'] as List<dynamic>?;
    if (list == null || list.isEmpty) return null;
    // return first team
    final t = list.first['team'];
    return {'id': t['id'], 'name': t['name']};
  }

  static Future<Map<String, dynamic>> fetchTeamGoalsAverages(int teamId, String apiFootballKey) async {
    // simplified: fetch last 10 matches and compute averages
    final url = Uri.parse('https://v3.football.api-sports.io/fixtures?team=$teamId&last=20');
    final resp = await http.get(url, headers: {'x-apisports-key': apiFootballKey});
    if (resp.statusCode != 200) {
      // fallback default
      return {'avg_for': 1.2, 'avg_against': 1.1, 'league_avg': 1.1};
    }
    final j = jsonDecode(resp.body);
    final arr = (j['response'] as List<dynamic>);
    double scoredHome = 0, concededHome = 0; int countHome = 0;
    double scoredAway = 0, concededAway = 0; int countAway = 0;
    for (var f in arr) {
      final goals = f['goals'];
      final home = f['teams']['home'];
      final away = f['teams']['away'];
      final homeScore = goals['home'];
      final awayScore = goals['away'];
      // determine if this team was home or away in that fixture
      if (home['id'] == teamId) {
        scoredHome += (homeScore ?? 0);
        concededHome += (awayScore ?? 0);
        countHome++;
      } else if (away['id'] == teamId) {
        scoredAway += (awayScore ?? 0);
        concededAway += (homeScore ?? 0);
        countAway++;
      }
    }
    final avgForHome = (countHome>0) ? (scoredHome / countHome) : 1.2;
    final avgAgainstHome = (countHome>0) ? (concededHome / countHome) : 1.0;
    final avgForAway = (countAway>0) ? (scoredAway / countAway) : 1.1;
    final avgAgainstAway = (countAway>0) ? (concededAway / countAway) : 1.1;
    return {
      'avg_for_home': avgForHome,
      'avg_against_home': avgAgainstHome,
      'avg_for_away': avgForAway,
      'avg_against_away': avgAgainstAway,
      'league_avg': 1.1,
      'opp_avg_against_away': avgAgainstAway,
      'opp_avg_against_home': avgAgainstHome,
      'avg_for': ((avgForHome + avgForAway)/2.0),
      'avg_against': ((avgAgainstHome + avgAgainstAway)/2.0),
    };
  }
}

/* ---------------------------
   Math functions (Poisson, Monte Carlo, Kelly)
   --------------------------- */

List<double> poissonList(double lam, int maxK) {
  List<double> res = [];
  for (int k=0; k<=maxK; k++) res.add(poissonPmf(k, lam));
  return res;
}

double poissonPmf(int k, double lam) {
  return exp(-lam) * pow(lam, k) / factorial(k);
}

double factorial(int n) {
  if (n <= 1) return 1.0;
  double f = 1.0;
  for (int i=2; i<=n; i++) f *= i;
  return f;
}

double exp(double x) => mathExp(x);
double mathExp(double x) => pow(e, x).toDouble();
const double e = 2.718281828459045;

Map<String, dynamic> runMonteCarlo(double lamH, double lamA, {int sims = 10000}) {
  final rng = Random();
  List<int> h = List<int>.filled(sims, 0);
  List<int> a = List<int>.filled(sims, 0);
  for (int i=0;i<sims;i++) {
    h[i] = samplePoisson(lamH, rng);
    a[i] = samplePoisson(lamA, rng);
  }
  int over25Count=0, over35Count=0, bttsCount=0, evenCount=0;
  Map<String,int> pairCount = {};
  for (int i=0;i<sims;i++) {
    final tot = h[i] + a[i];
    if (tot > 2) over25Count++;
    if (tot > 3) over35Count++;
    if (h[i] >=1 && a[i] >=1) bttsCount++;
    if (tot % 2 == 0) evenCount++;
    final key = '${h[i]}-${a[i]}';
    pairCount[key] = (pairCount[key] ?? 0) + 1;
  }
  final sortedPairs = pairCount.entries.toList()
    ..sort((a,b) => b.value.compareTo(a.value));
  final topScores = sortedPairs.take(12).map((e) => {'score': e.key, 'prob': e.value / sims}).toList();
  return {
    'over_2.5': over25Count / sims,
    'over_3.5': over35Count / sims,
    'btts': bttsCount / sims,
    'even': evenCount / sims,
    'top_scores': topScores
  };
}

int samplePoisson(double lam, Random rng) {
  // Knuth algorithm
  final L = exp(-lam);
  int k = 0;
  double p = 1.0;
  while (p > L) {
    k++;
    p *= rng.nextDouble();
    if (k > 50) break;
  }
  return k-1 < 0 ? 0 : k-1;
}

double probOverX(double lam, double x) {
  // approximate P(total > x) with Poisson on lam (where lam = lambda_home + lambda_away)
  int floorX = x.floor();
  double cdf = 0.0;
  for (int k=0; k<=floorX; k++) cdf += poissonPmf(k, lam);
  return 1.0 - cdf;
}

double kellyFraction(double marketOdds, double fairProb) {
  // convert decimal odds to implied
  double implied = 1.0 / marketOdds;
  double b = marketOdds - 1.0;
  double p = fairProb;
  double q = 1 - p;
  double numerator = b * p - q;
  if (b <= 0) return 0.0;
  double f = numerator / b;
  return f < 0 ? 0.0 : f;
}

/* ---------------------------
   Utility for JSON encoding fallback
   --------------------------- */
dynamic toEncodableFallback(dynamic o) {
  return o.toString();
}
